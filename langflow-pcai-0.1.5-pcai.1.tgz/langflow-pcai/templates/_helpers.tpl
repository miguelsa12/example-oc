{{- define "lf.name" -}}
{{- .Values.fullnameOverride | default .Release.Name | trunc 48 | trimSuffix "-" -}}
{{- end -}}
{{- define "lf.labels" -}}
app.kubernetes.io/name: langflow-pcai
app.kubernetes.io/instance: {{ .Release.Name | quote }}
hpe-ezua/type: vendor-service
hpe-ezua/app: {{ .Chart.Name | quote }}
{{- end -}}
{{- define "lf.selector" -}}
app.kubernetes.io/name: langflow-pcai
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}
{{- define "lf.authSecret" -}}
{{- .Values.auth.existingSecret | default (printf "%s-auth" (include "lf.name" .)) -}}
{{- end -}}
{{- define "lf.dbHost" -}}
{{- if .Values.postgresql.enabled -}}
{{- .Values.postgresql.fullnameOverride | default (printf "%s-postgresql" .Release.Name) -}}
{{- else -}}
{{- required "database.external.host is required when postgresql.enabled=false" .Values.database.external.host -}}
{{- end -}}
{{- end -}}
{{- define "lf.dbSecret" -}}
{{- if .Values.postgresql.enabled -}}
{{- .Values.postgresql.auth.existingSecret | default (include "lf.dbHost" .) -}}
{{- else -}}
{{- required "database.external.existingSecret is required" .Values.database.external.existingSecret -}}
{{- end -}}
{{- end -}}
